import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _cc5a2b78 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _70a43b0e = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _2e46b50f = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _ded70462 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _133b4cbd = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _e3f7def2 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _775ec11c = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _cc5a2b78,
    children: [{
      path: "",
      component: _70a43b0e,
      name: "home"
    }, {
      path: "/login",
      component: _2e46b50f,
      name: "login"
    }, {
      path: "/register",
      component: _2e46b50f,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _ded70462,
      name: "profile"
    }, {
      path: "/settings",
      component: _133b4cbd,
      name: "settings"
    }, {
      path: "/editor",
      component: _e3f7def2,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _775ec11c,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
